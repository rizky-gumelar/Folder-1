<?php

namespace App\Controllers;

use App\Models\ObatModel;

class ObatController extends BaseController
{
    public function index()
    {
        $obat = new ObatModel();
        $data['obat'] = $obat->getData();

        return view('obat/Entry_obat', $data);
    }

    public function new()
    {
        return view('obat/tambah');
    }

    public function create()
    {
        $obat = new ObatModel();
        $query = [
            "kode_obat" => $this->request->getPost('kode_obat'),
            "nama_obat" => $this->request->getPost('nama_obat'),
            "satuan_obat" => $this->request->getPost('satuan_obat'),
            "jenis_obat" => $this->request->getPost('jenis_obat'),
            "jumlah" => $this->request->getPost('jumlah')
        ];
        $obat->createData($query);
        return redirect('obat');
    }

    public function edit($id = null)
    {
        $obat = new ObatModel();
        $data['obat'] = $obat->getDataById($id);
        return view('obat/ubah', $data);
    }

    public function update($id = null)
    {
        $obat = new ObatModel();
        $query = [
            "kode_obat" => $this->request->getPost('kode_obat'),
            "nama_obat" => $this->request->getPost('nama_obat'),
            "satuan_obat" => $this->request->getPost('satuan_obat'),
            "jenis_obat" => $this->request->getPost('jenis_obat'),
            "jumlah" => $this->request->getPost('jumlah')
        ];
        $data['obat'] = $obat->updateData($id, $query);
        return redirect('obat');
    }

    public function delete($id = null)
    {
        $obat = new ObatModel();
        $obat->delete($id);
        return redirect('obat');
    }
}
