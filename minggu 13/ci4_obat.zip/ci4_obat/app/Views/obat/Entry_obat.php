<html>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col">
                <h2 style="text-align: center">DATA OBAT</h2>
                <a class="btn btn-success" href="obat/new">Tambah Obat</a>
                <br><br>
                <table class="table" style="width:100%; margin: auto">
                    <tr class="text-light bg-primary">
                        <td>KODE</td>
                        <td>NAMA OBAT</td>
                        <td>SATUAN</td>
                        <td>JENIS OBAT</td>
                        <td>JUMLAH</td>
                        <td>AKSI</td>
                    </tr>

                    <?php foreach ($obat as $data) : ?>
                        <tr>
                            <td><?php echo $data['kode_obat']; ?></td>
                            <td><?php echo $data['nama_obat']; ?></td>
                            <td><?php echo $data['satuan_obat']; ?></td>
                            <td><?php echo $data['jenis_obat']; ?></td>
                            <td><?php echo $data['jumlah']; ?></td>
                            <td><a class="btn btn-success" href="obat/<?= $data['kode_obat'] ?>/edit">Edit</a> | <a class="btn btn-danger" href="obat/<?= $data['kode_obat'] ?>/delete" onclick="return confirm('Apakah anda yakin akan menghapus <?= $data['nama_obat']; ?>?')">Delete</a></td>
                        </tr>
                    <?php endforeach; ?>
                </table>

                
                <br><br>
                <p>Nama : Rizky Syah Gumelar<br>NIM : A11.2021.13304<br>Kelompok : A11.4227</p>
            </div>
        </div>
    </div>


</body>

</html>