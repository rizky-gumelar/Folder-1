<?php

namespace App\Models;

use CodeIgniter\Model;

class ObatModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'obat';
    protected $primaryKey       = 'kode_obat';
    //protected $useAutoIncrement = true;
    protected $allowedFields    = ['kode_obat', 'nama_obat', 'satuan_obat', 'jenis_obat', 'jumlah'];

    public function getData()
    {
        return $this->findAll();
    }
    public function getDataById($id)
    {
        return $this->where('kode_obat', $id)->first();
    }
    public function createData($data)
    {
        return $this->insert($data);
    }
    public function updateData($id, $data)
    {
        return $this->update($id, $data);
    }
}
